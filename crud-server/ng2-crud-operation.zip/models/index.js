'use strict';
const db = require('./db');
const userSchema = require('./userSchema')

module.exports = { db, userSchema }